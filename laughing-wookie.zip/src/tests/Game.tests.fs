﻿module GameTests

open Xunit
open FsUnit.Xunit


//type ``Given a signedIn user `` ()=
//   let lightBulb = new LightBulb(true)
//
//   [<Fact>] member test.
//    ``when I create a game, it should takes place in 24 hours.`` ()=
//           Given [Events.Signedin("LastName1","FirstName1","usr1","pwd1")]
//           When Commands.Login("usr1","pwd1")
//           Then [Events.Loggedin("usr1",guid,DateTime.Now())]

   