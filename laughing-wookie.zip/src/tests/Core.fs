﻿module Core

//let Given (events: a' list) =
open System

let repoAuth =
    let isLoggedIn tokenId = Some(DateTime.Now,"usernameToto")
    let login ((username,password):string*string) = Some("tokenid",DateTime.Now)
    let saveSession username (tokenid:Guid) (expirationDate:DateTime) = "saved" |> ignore        
    login,saveSession, isLoggedIn

let makeEventRepo : string -> (Type *Guid-> seq<obj>) *(Guid*int-> obj->unit)
    


    


