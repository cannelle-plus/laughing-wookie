laughing-wookie
===============

back office app

This starts an httpListenner. 
The API so far is only http://localhost:8081/game/create.